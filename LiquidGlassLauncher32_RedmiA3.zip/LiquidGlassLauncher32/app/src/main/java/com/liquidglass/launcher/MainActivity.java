package com.liquidglass.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.*;
import android.widget.Toast;
import java.util.*;

public class MainActivity extends Activity {
    LiquidView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        view = new LiquidView();
        setContentView(view);
    }

    class AppItem {
        String name;
        Drawable icon;
        Intent intent;
        AppItem(String n, Drawable i, Intent x) { name=n; icon=i; intent=x; }
    }

    class LiquidView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        ArrayList<AppItem> apps = new ArrayList<>();
        float downX;
        int page = 0;
        int cols = 4;
        int rows = 4;

        LiquidView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            loadApps();
        }

        void loadApps() {
            PackageManager pm = getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN, null);
            q.addCategory(Intent.CATEGORY_LAUNCHER);
            List<android.content.pm.ResolveInfo> list = pm.queryIntentActivities(q, 0);
            Collections.sort(list, (a,b) -> a.loadLabel(pm).toString()
                    .compareToIgnoreCase(b.loadLabel(pm).toString()));

            for (android.content.pm.ResolveInfo r : list) {
                if (r.activityInfo.packageName.equals(getPackageName())) continue;
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(r.activityInfo.packageName, r.activityInfo.name);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                apps.add(new AppItem(r.loadLabel(pm).toString(), r.loadIcon(pm), launch));
            }
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            p.setShader(new LinearGradient(0,0,w,h,
                    new int[]{Color.rgb(10,14,28),Color.rgb(42,53,88),Color.rgb(18,20,34)},
                    null, Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);
            p.setShader(null);

            // Liquid glow blobs
            p.setMaskFilter(new BlurMaskFilter(55, BlurMaskFilter.Blur.NORMAL));
            p.setColor(Color.argb(55,90,150,255));
            c.drawCircle(w*0.78f,h*0.20f,110,p);
            p.setColor(Color.argb(45,70,255,220));
            c.drawCircle(w*0.12f,h*0.72f,100,p);
            p.setMaskFilter(null);

            p.setColor(Color.WHITE);
            p.setTextSize(17);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(currentTime(), 22, 32, p);

            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(13);
            p.setColor(Color.argb(195,255,255,255));
            c.drawText("Liquid Glass", 22, 58, p);

            // Weather glass card
            float cardL=18, cardT=78, cardR=w-18, cardB=158;
            glass(c,cardL,cardT,cardR,cardB,28);
            p.setColor(Color.WHITE); p.setTextSize(29);
            c.drawText("24°", 38, 116, p);
            p.setTextSize(12); p.setColor(Color.argb(190,255,255,255));
            c.drawText("Partly cloudy", 38, 140, p);
            c.drawText("Swipe left / right", w-120, 140, p);

            int start = page*cols*rows;
            int cellW=w/cols;
            int gridTop=185;
            int cellH=82;
            for(int i=0;i<cols*rows;i++){
                int idx=start+i;
                if(idx>=apps.size()) break;
                int col=i%cols, row=i/cols;
                float cx=cellW*col+cellW/2f;
                float cy=gridTop+row*cellH+32;
                drawIcon(c, apps.get(idx).icon, cx, cy);
                p.setTextAlign(Paint.Align.CENTER);
                p.setColor(Color.WHITE);
                p.setTextSize(11);
                String n=apps.get(idx).name;
                if(n.length()>12) n=n.substring(0,11)+"…";
                c.drawText(n,cx,cy+40,p);
                p.setTextAlign(Paint.Align.LEFT);
            }

            // Page dots
            int pages=Math.max(1,(apps.size()+cols*rows-1)/(cols*rows));
            p.setColor(Color.WHITE);
            for(int i=0;i<pages;i++) {
                c.drawCircle(w/2f+(i-(pages-1)/2f)*13,h-108, i==page?4:3,p);
                if(i!=page) p.setColor(Color.argb(80,255,255,255));
            }

            // Dock
            float dl=18, dt=h-92, dr=w-18, db=h-18;
            glass(c,dl,dt,dr,db,32);
            int dockCount=Math.min(4,apps.size());
            for(int i=0;i<dockCount;i++) {
                float cx=dl+(dr-dl)*(i+0.5f)/dockCount;
                drawIcon(c, apps.get(i).icon, cx,(dt+db)/2);
            }
        }

        String currentTime() {
            Calendar x=Calendar.getInstance();
            return String.format(Locale.getDefault(),"%d:%02d",
                    x.get(Calendar.HOUR_OF_DAY),x.get(Calendar.MINUTE));
        }

        void glass(Canvas c,float l,float t,float r,float b,float rad) {
            p.setColor(Color.argb(34,255,255,255));
            c.drawRoundRect(l,t,r,b,rad,rad,p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.2f);
            p.setColor(Color.argb(65,255,255,255));
            c.drawRoundRect(l,t,r,b,rad,rad,p);
            p.setStyle(Paint.Style.FILL);
        }

        void drawIcon(Canvas c, Drawable d, float cx, float cy) {
            int s=54;
            float l=cx-s/2f, t=cy-s/2f;
            p.setShadowLayer(12,0,5,Color.argb(80,0,0,0));
            p.setColor(Color.argb(55,255,255,255));
            c.drawRoundRect(l,t,l+s,t+s,15,15,p);
            p.clearShadowLayer();
            d.setBounds((int)l+4,(int)t+4,(int)l+s-4,(int)t+s-4);
            d.draw(c);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_DOWN){ downX=e.getX(); return true; }
            if(e.getAction()==MotionEvent.ACTION_UP){
                float dx=e.getX()-downX;
                int pages=Math.max(1,(apps.size()+cols*rows-1)/(cols*rows));
                if(Math.abs(dx)>80) {
                    if(dx<0 && page<pages-1) page++;
                    if(dx>0 && page>0) page--;
                    invalidate(); return true;
                }
                float y=e.getY(), x=e.getX();
                int h=getHeight(), w=getWidth();
                if(y>=185 && y<h-120) {
                    int col=(int)(x/(w/(float)cols));
                    int row=(int)((y-185)/82);
                    if(col>=0&&col<cols&&row>=0&&row<rows){
                        int idx=page*cols*rows+row*cols+col;
                        if(idx<apps.size()) {
                            try { startActivity(apps.get(idx).intent); }
                            catch(Exception ex){ Toast.makeText(MainActivity.this,"Tak dapat buka app",Toast.LENGTH_SHORT).show(); }
                        }
                    }
                }
                return true;
            }
            return true;
        }
    }
}
