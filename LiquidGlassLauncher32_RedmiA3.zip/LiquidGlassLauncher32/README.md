# Liquid Glass Launcher 32-bit — Redmi A3

This edition is intentionally lightweight:
- Java only (no Jetpack Compose / AndroidX dependency)
- 32-bit friendly
- Gradle ABI filter: armeabi-v7a
- Real installed app icons and launch intents
- Home launcher intent
- Liquid-glass style background, cards and dock
- Swipe between app pages

Important:
Redmi A3 uses a 32-bit Android system even though its CPU is 64-bit. Xiaomi states that it can only install 32-bit applications. The Android ABI used for 32-bit ARM is armeabi-v7a.

Build on a compatible Android IDE such as an IDE that supports 32-bit devices. If your current AndroidIDE app says "32-bit devices are not supported", that is the IDE limitation, not this project's target ABI.

To use:
1. Extract this ZIP on the phone.
2. Open the project root in a compatible Android IDE.
3. Build APK.
4. Install APK.
5. Press Home and choose "Liquid Glass" as the Home app.

The project intentionally avoids native libraries and heavy UI dependencies.
