DeX Lite — Android IDE Ready
==============================

Project type: Android Gradle project
Package: com.dexlite
Build: debug
Output: app/build/outputs/apk/debug/app-debug.apk

PHONE-ONLY BUILD (NO TERMUX)
1. Install an Android IDE that supports Android Gradle projects and has/uses the Android SDK.
2. Extract this ZIP to internal storage.
3. In the IDE choose Open/Import Existing Gradle Project.
4. Select the folder containing settings.gradle.
5. Wait for Gradle sync and SDK components to finish.
6. Choose Build > Assemble Debug / Build APK (exact wording depends on the IDE).
7. Install the resulting app-debug.apk.

IMPORTANT
- Do NOT rename this ZIP to .apk.
- The first build may download Gradle/Android SDK components and can require significant storage.
- This is a DeX-style launcher prototype, not Samsung DeX.
- It does not require root.
- The prototype cannot force unsupported Android apps into true freeform windows.
