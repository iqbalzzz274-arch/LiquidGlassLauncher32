package com.dexlite;

import android.app.*; import android.os.*; import android.content.*; import android.content.pm.*;
import android.graphics.Color; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 ArrayList<AppInfo> all=new ArrayList<>(), shown=new ArrayList<>(); AppAdapter adapter;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  GridView g=findViewById(R.id.apps); adapter=new AppAdapter(this,shown); g.setAdapter(adapter); load();
  EditText s=findViewById(R.id.search); s.addTextChangedListener(new android.text.TextWatcher(){
   public void beforeTextChanged(CharSequence x,int a,int c,int d){} public void afterTextChanged(android.text.Editable x){}
   public void onTextChanged(CharSequence x,int a,int b,int c){filter(x.toString());}});
 }
 void load(){PackageManager pm=getPackageManager(); Intent i=new Intent(Intent.ACTION_MAIN,null);i.addCategory(Intent.CATEGORY_LAUNCHER);
  for(ResolveInfo r:pm.queryIntentActivities(i,0)) all.add(new AppInfo(r.loadLabel(pm).toString(),r.activityInfo.packageName,r.activityInfo.name,r.loadIcon(pm)));
  Collections.sort(all,(a,b)->a.name.compareToIgnoreCase(b.name));shown.addAll(all);adapter.notifyDataSetChanged();}
 void filter(String q){shown.clear();for(AppInfo a:all)if(a.name.toLowerCase().contains(q.toLowerCase()))shown.add(a);adapter.notifyDataSetChanged();}
 static class AppInfo{String name,pkg,act;android.graphics.drawable.Drawable icon;AppInfo(String n,String p,String a,android.graphics.drawable.Drawable i){name=n;pkg=p;act=a;icon=i;}}
 static class AppAdapter extends BaseAdapter{
  Context c;ArrayList<AppInfo>d;AppAdapter(Context c,ArrayList<AppInfo>d){this.c=c;this.d=d;}
  public int getCount(){return d.size();}public Object getItem(int p){return d.get(p);}public long getItemId(int p){return p;}
  public View getView(int p,View v,ViewGroup par){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.CENTER);
   ImageView im=new ImageView(c);im.setImageDrawable(d.get(p).icon);l.addView(im,new LinearLayout.LayoutParams(50,50));
   TextView t=new TextView(c);t.setText(d.get(p).name);t.setTextColor(Color.WHITE);t.setTextSize(11);t.setGravity(Gravity.CENTER);l.addView(t,new LinearLayout.LayoutParams(-1,38));
   l.setOnClickListener(x->{try{Intent z=new Intent();z.setComponent(new ComponentName(d.get(p).pkg,d.get(p).act));c.startActivity(z);}catch(Exception e){}});return l;}
 }
}
